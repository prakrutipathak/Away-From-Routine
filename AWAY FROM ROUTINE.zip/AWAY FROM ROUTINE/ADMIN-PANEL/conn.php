<?php

   $conn = mysqli_connect('localhost','root','','useform');

   if($conn == false){
       echo "Connection Failed!";
   }
   
?>